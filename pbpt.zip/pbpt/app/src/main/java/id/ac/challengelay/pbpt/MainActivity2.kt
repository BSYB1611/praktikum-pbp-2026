package id.ac.challengelay.pbpt

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val tvNama = findViewById<TextView>(R.id.tvNama)
        val tvUmur = findViewById<TextView>(R.id.tvUmur)
        val image = findViewById<ImageView>(R.id.image)

        val nama = intent.getStringExtra("EXTRA_SENDER") ?: ""
        val umur = intent.getStringExtra("EXTRA_AGE") ?: ""
        val gambar = intent.getIntExtra("EXTRA_GAMBAR", 0)

        tvNama.text = getString(R.string.label_name, nama)
        tvUmur.text = getString(R.string.label_age, umur)

        if (gambar != 0) {
            image.setImageResource(gambar)
        }
    }
}