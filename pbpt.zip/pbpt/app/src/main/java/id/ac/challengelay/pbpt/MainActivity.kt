package id.ac.challengelay.pbpt

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)){v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val etNama = findViewById<EditText>(R.id.etNama)
        val etUmur = findViewById<EditText>(R.id.etUmur)
        val btnSave = findViewById<Button>(R.id.btnSave)

        btnSave.setOnClickListener {
            val nama = etNama.text.toString().trim()
            val age = etUmur.text.toString().trim()

            if (nama.isEmpty()) {
                etNama.error = "Name is required!"
                Toast.makeText(this, "Please fill in your name first!", Toast.LENGTH_SHORT).show()
            }else if (age.isEmpty()){
                etUmur.error = "Age is required!"
                Toast.makeText( this, "Please fill in your age first!", Toast.LENGTH_SHORT).show()
            }else {
                val intent = Intent(this, MainActivity2::class.java)
                intent.putExtra("EXTRA_SENDER", nama)
                intent.putExtra("EXTRA_AGE", age)
                startActivity(intent)

            }
        }


    }
}